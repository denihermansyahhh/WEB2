<?php
include("koneksi.php");
include("navbar.php");
?>


    <div class="container">
		<div class="content">
			<!-- <div class="row mt-3"> -->
				<h2>Data Akun &raquo; Lihat Data Akun</h2>
				<hr />
				<br />
			
			<!-- memulai tabel responsive -->
			<div class="table-responsive">
				<table class="table table-striped table-hover">
					<tr>
						<th>Nama</th>
						<th>Email</th>
						<th>Username</th>
						<th>Password</th>
						<th></th>
						<th>Aksi</th>
					</tr>
					<?php
					
						$sql = mysqli_query($koneksi, "SELECT * FROM tb_dataAkun ORDER BY username ASC"); // jika tidak ada filter maka tampilkan semua entri
					
						$no = 1; // mewakili data dari nomor 1
						while($row = mysqli_fetch_assoc($sql)){ // fetch query yang sesuai ke dalam array
							echo '
							<tr>
								<td>'.$row['nama'].'</td>
								<td>'.$row['email'].'</td>
								<td>'.$row['username'].'</td>
								<td>'.$row['password'].'</td>
								<td>';
								
							echo '
								</td>
								<td>

								<a href="edit.php?username='.$row['username'].'">Edit</a>
								<a href="password.php?username='.$row['username'].'">Ubah Pass</a>
								<a href="hapus.php?aksi=delete&username='.$row['username'].'" onclick="return confirm(\'Anda yakin akan menghapus data '.$row['username'].'?\')">Hapus</a>

								</td>
							</tr>
							';
							$no++; // mewakili data kedua dan seterusnya
						}
					
					?>
				</table>
			</div> <!-- /.table-responsive -->
		</div> <!-- /.content -->
	</div> <!-- /.container -->