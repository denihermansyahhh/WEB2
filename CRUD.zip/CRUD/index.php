<?php
include("koneksi.php");
include("navbar.php");
?>

<!-- Start container -->
  <div class="container">
    <div class="content">
      <div class="jumbotron">
        <h1>Data Akun</h1>

<!-- button lihat data -->
        <a href="lihatdata.php" data-toggle="tooltip" title="Lihat Data Akun" class="btn btn-info" role="button">
          <span class="glyphicon glyphicon-list"></span>Lihat Data Akun</a>

<!-- button tambah data -->
        <a href="tambah.php" data-toggle="tooltip" title="Tambah Data Akun" class="btn btn-success" role="button">
          <span class="glyphicon glyphicon-user"></span>Tambah Data</a>
      </div>
    </div>
  </div>

<!-- End container -->