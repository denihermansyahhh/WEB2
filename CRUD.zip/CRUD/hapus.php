
<!-- include("koneksi.php");


$hapus = mysqli_query($koneksi, "DELETE * FROM tb_dataAkun WHERE username='$username'");

echo "<script>alert('Data dihapus !');</script>";
echo "<script>location='lihatdata.php';</script>"; -->


<!-- include ("koneksi.php");
$username = $_GET['username'];
$hapus = mysqli_query($koneksi, "DELETE * FROM tb_dataAkun WHERE username='$username'")or die(mysql_error($koneksi));

header("location:lihatdata.php?pesan=hapus"); -->

<?php
include 'koneksi.php';
// menyimpan data id kedalam variabel
$username   = $_GET['username'];
// query SQL untuk insert data
$query="DELETE from tb_dataAkun where username='$username'";
mysqli_query($koneksi, $query);
// mengalihkan ke halaman index.php
header("location:lihatdata.php");
?>