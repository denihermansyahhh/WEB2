<?php
include("koneksi.php");
include("navbar.php");
?>

    <div class="container">
        <div class="content">
            <h2>Data Akun &raquo; Tambah Akun</h2>
            <hr />
            <br />


            <?php
            if(isset($_POST['add'])){ // jika tombol 'Simpan' dengan properti name="add" pada baris 164 ditekan

                  $nama         = $_POST['nama'];
                  $username     = $_POST['username'];
                  $pass1        = $_POST['pass1'];
                  $pass2        = $_POST['pass2'];
                  $email        = $_POST['email'];
              
              
              $cek = mysqli_query($koneksi, "SELECT * FROM tb_dataAkun WHERE username='$username'"); // query untuk memilih entri dengan username terpilih
              if(mysqli_num_rows($cek) == 0){ // mengecek apakah username yang akan ditambahkan tidak ada dalam database
                if($pass1 == $pass2){ // mengecek apakah nilai pada pass1 dan pass2 bernilai sama
                  

                  if(strlen($pass1) >= 6) {
                    $pass = ($pass1); // assigment variabel pass dengan nilai pass1

                     $insert = mysqli_query($koneksi, "INSERT INTO tb_dataAkun(nama, username, password, email) VALUES('$nama', '$username', '$pass', '$email')") or die(mysqli_error($koneksi)); // query untuk menambahkan data ke dalam database
                    if($insert){ // jika query insert berhasil dieksekusi
                      echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close"  data-dismiss="alert" aria-hidden="true">&times;</button>Data Akun Berhasil Di Simpan. <a href="lihatdata.php"><- Kembali</a></div>'; // maka tampilkan 'Data Mahasiswa Berhasil Di Simpan.'
                    }else{ // jika query insert gagal dieksekusi
                       echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Ups, Data Akun Gagal Di simpan! <a href="tambah.php"><- Kembali</a></div>'; // maka tampilkan 'Ups, Data Mahasiswa Gagal Di simpan!'
                    }

                  }else{ // jika panjang password kurang dari 6 karakter 
                    echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Panjang karakter Password minimal 6 karakter.</div>'; // maka tampilkan 'Panjang karakter Password minimal 6 karakter.'
                    }

                } else{ // mengecek jika password yang diinput tidak sama
                  echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Password Tidak sama!</div>'; // maka tampilkan 'Password Tidak sama!'
                }
              }else{ // mengecek jika username yang akan ditambahkan sudah ada dalam database
                echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Username Sudah Ada..! <a href="index.php"><- Kembali</a></div>'; // maka tampilkan 'username Sudah Ada..!'
              }
            }
            ?>


          </div>


      <form class="form-horizontal" action="" method="post">

        <div class="form-group">
          <label class="col-sm-3 control-label">Nama</label>
          <div class="col-sm-4">
            <input type="text" name="nama" class="form-control" required>
          </div>
        </div>

        <div class="form-group">
          <label class="col-sm-3 control-label">Email</label>
          <div class="col-sm-4">
            <input type="email" name="email" class="form-control" required>
          </div>
        </div>

        <div class="form-group">
          <label class="col-sm-3 control-label">Username</label>
          <div class="col-sm-4">
            <input type="text" name="username" class="form-control" required>
          </div>
        </div>

        <div class="form-group">
          <label class="col-sm-3 control-label">Password</label>
          <div class="col-sm-3">
            <input type="password" name="pass1" class="form-control" placeholder="min. 6 karakter" required>
          </div>
        </div>

        <div class="form-group">
          <label class="col-sm-3 control-label">Ulangi Password</label>
          <div class="col-sm-3">
            <input type="password" name="pass2" class="form-control" required>
          </div>
        </div>

        

        <div class="form-group">
          <label class="col-sm-3 control-label">&nbsp;</label>
          <div class="col-sm-6">
            <input type="submit" name="add" class="btn btn-sm btn-primary" value="Simpan" data-toggle="tooltip" title="Simpan Data Akun">
            <a href="index.php" class="btn btn-sm btn-danger" data-toggle="tooltip" title="Batal">Batal</a>
          </div>
        </div>

      </form>

          
        </div>
      </div>